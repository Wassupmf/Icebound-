# ICEBOUND Daily — website starter

This is a deployable static website plus a Supabase backend setup. It provides:
- Public daily-game homepage
- Public archive and replay pages
- Private email/password administrator login
- HTML upload and publish by date
- Published games remain available in the archive
- HTML games run in a sandboxed iframe on Supabase Storage's separate origin

## Important: what is not configured yet

This package is not live on the internet yet. You must create a Supabase project and a Cloudflare Pages site, then connect them. No hosting account or administrator password has been created for you.

## 1. Create the database and storage

1. Create a free project at https://supabase.com/.
2. Open **SQL Editor** in the Supabase dashboard.
3. Open `supabase.sql` from this folder, copy all of it, paste it into SQL Editor, and run it.
4. In Supabase, open **Project Settings → API**. Copy the Project URL and the `anon` / publishable public key.
5. Edit `config.js` and replace the two `PASTE_...` values. Never use a `service_role` or secret key in browser code.

## 2. Create your administrator login

1. In Supabase, open **Authentication → Users**.
2. Create a user with your email and a strong password. Keep public sign-ups disabled.
3. Copy that user's UUID.
4. In SQL Editor run this, replacing the placeholder with your UUID:

   `insert into public.icebound_admins(user_id) values ('YOUR-USER-UUID');`

Only users listed in `icebound_admins` can upload or publish games.

## 3. Publish the website

1. Create a free account at https://cloudflare.com/ and open **Workers & Pages → Create → Pages**.
2. Choose **Upload assets** / direct upload.
3. Upload the contents of this folder (the files themselves, not the ZIP).
4. Cloudflare will provide a public `*.pages.dev` address.

For future website changes, upload the updated site files to the same Pages project. Daily game changes do not require redeploying the website: use `/admin.html` to upload the day's standalone HTML file.

## 4. Daily publishing workflow

1. Open your website address followed by `/admin.html`.
2. Sign in with the administrator account.
3. Enter a title and date.
4. Select the standalone `.html` game file and press **Upload and publish**.
5. The homepage displays the latest published game (today's game if one exists); the archive lists all published dates.

Uploading a second game for the same date updates that date's archive entry to the new file. Older dates remain untouched.

## 5. Game file requirements and safety

- Upload a complete standalone HTML file, not a ZIP.
- Keep it under 2 MB.
- Keep CSS and JavaScript inside the HTML file, or use publicly hosted assets.
- Uploaded games are embedded with a restrictive iframe sandbox and do not receive the administrator site's origin or credentials.
- A game must implement its own rules, question timer, and answer checking. The upload portal stores and publishes the file; it does not automatically add a 30-second timer to arbitrary uploaded code.
- For a daily game with a 30-second timer, that timer must be included in the HTML game you upload.

## Notes

This starter uses Supabase's public browser key with row-level security. Do not paste a secret/service-role key into `config.js`. Do not share your administrator password.
