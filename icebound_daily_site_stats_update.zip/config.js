// Add your Supabase project URL and anon/public key here after creating the project.
// These are public browser credentials; never put a service_role key in this file.
window.ICEBOUND_CONFIG = {
  SUPABASE_URL: "https://wluichjxaeqbaijnvzbu.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_535AcELaFarroulY2RPDdw_aSyGSvx-"
};