-- Run this in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.games (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 1 and 90),
  game_date date not null unique,
  storage_path text not null,
  published boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.icebound_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.games enable row level security;
alter table public.icebound_admins enable row level security;

-- Anyone can see published game metadata; only admins can change it.
create policy "Public can read published games" on public.games
  for select using (published = true);
create policy "Admins can read all games" on public.games
  for select to authenticated
  using (exists (select 1 from public.icebound_admins a where a.user_id = auth.uid()));
create policy "Admins can insert games" on public.games
  for insert to authenticated
  with check (exists (select 1 from public.icebound_admins a where a.user_id = auth.uid()));
create policy "Admins can update games" on public.games
  for update to authenticated
  using (exists (select 1 from public.icebound_admins a where a.user_id = auth.uid()))
  with check (exists (select 1 from public.icebound_admins a where a.user_id = auth.uid()));
create policy "Admins can delete games" on public.games
  for delete to authenticated
  using (exists (select 1 from public.icebound_admins a where a.user_id = auth.uid()));

-- Create a PUBLIC bucket. Game HTML is served from Supabase's separate storage origin
-- and embedded in a sandboxed iframe, isolated from the admin site's origin.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('daily-games', 'daily-games', true, 2097152, array['text/html'])
on conflict (id) do update set public = true, file_size_limit = 2097152, allowed_mime_types = array['text/html'];

create policy "Public can read daily game files" on storage.objects
  for select using (bucket_id = 'daily-games');
create policy "Admins can upload daily game files" on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'daily-games' and
    exists (select 1 from public.icebound_admins a where a.user_id = auth.uid())
  );
create policy "Admins can update daily game files" on storage.objects
  for update to authenticated
  using (
    bucket_id = 'daily-games' and
    exists (select 1 from public.icebound_admins a where a.user_id = auth.uid())
  )
  with check (
    bucket_id = 'daily-games' and
    exists (select 1 from public.icebound_admins a where a.user_id = auth.uid())
  );
create policy "Admins can delete daily game files" on storage.objects
  for delete to authenticated
  using (
    bucket_id = 'daily-games' and
    exists (select 1 from public.icebound_admins a where a.user_id = auth.uid())
  );

-- After creating your admin user in Supabase Authentication, copy their UUID
-- and run: insert into public.icebound_admins(user_id) values ('YOUR-USER-UUID');
