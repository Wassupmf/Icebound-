(() => {
  const cfg = window.ICEBOUND_CONFIG || {};
  const configured = cfg.SUPABASE_URL && cfg.SUPABASE_ANON_KEY &&
    !cfg.SUPABASE_URL.includes("PASTE_") && !cfg.SUPABASE_ANON_KEY.includes("PASTE_");
  const client = configured && window.supabase
    ? window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY)
    : null;
  const $ = id => document.getElementById(id);
  const dateLabel = value => new Date(value + "T12:00:00").toLocaleDateString(undefined,{day:"numeric",month:"long",year:"numeric"});
  const showConfigError = id => { if ($(id)) $(id).textContent = "The site has not been connected to its database yet. Follow SETUP.md to connect Supabase."; };
  async function getGames() {
    const {data,error} = await client.from("games").select("id,title,game_date,storage_path,created_at").eq("published",true).order("game_date",{ascending:false});
    if (error) throw error; return data || [];
  }
  function publicFileUrl(path) {
    return client.storage.from("daily-games").getPublicUrl(path).data.publicUrl;
  }
  // Give each uploaded daily game its own date, including archive replays.
  function prepareGameHtml(html, gameDate) {
    return html.replace(/const CHALLENGE_DATE='\d{4}-\d{2}-\d{2}';/, "const CHALLENGE_DATE='" + gameDate + "';");
  }
  async function home() {
    if (!client) return showConfigError("state");
    try {
      const games = await getGames();
      const today = new Date().toLocaleDateString("en-CA");
      const game = games.find(g => g.game_date === today) || games[0];
      if (!game) { $("state").textContent = "No challenge has been published yet. Please check back soon."; return; }
      $("game-title").textContent = game.title; $("game-date").textContent = dateLabel(game.game_date);
      $("state").textContent = "Loading the game…";
      const response = await fetch(publicFileUrl(game.storage_path), {cache:"no-store"});
      if (!response.ok) throw new Error("Game file returned HTTP " + response.status);
      const gameHtml = prepareGameHtml(await response.text(), game.game_date);
      $("game-frame").srcdoc = gameHtml;
      $("state").hidden = true; $("game-frame").hidden = false;
    } catch(e) { $("state").textContent = "Couldn't load today's game: " + e.message; }
  }
  async function archive() {
    if (!client) return showConfigError("archive-state");
    try {
      const games = await getGames();
      $("archive-state").textContent = games.length ? `${games.length} published challenge${games.length===1?"":"s"}.` : "No archived games yet.";
      $("archive-list").innerHTML = "";
      for (const g of games) {
        const a = document.createElement("a"); a.className="archive-item";
        a.href = `play.html?id=${encodeURIComponent(g.id)}`;
        const left=document.createElement("span"), right=document.createElement("span");
        const strong=document.createElement("strong"); strong.textContent=g.title;
        const small=document.createElement("small"); small.textContent=dateLabel(g.game_date);
        left.append(strong,small); right.textContent="PLAY →"; a.append(left,right); $("archive-list").append(a);
      }
    } catch(e) { $("archive-state").textContent = "Couldn't load the archive: " + e.message; }
  }
  async function replay() {
    if (!client) return showConfigError("replay-state");
    try {
      const id = new URLSearchParams(location.search).get("id");
      if (!id) throw new Error("No archived game was selected.");
      const {data,error}=await client.from("games").select("*").eq("id",id).eq("published",true).single();
      if(error) throw error;
      $("replay-title").textContent=data.title; $("replay-date").textContent=dateLabel(data.game_date);
      const response = await fetch(publicFileUrl(data.storage_path), {cache:"no-store"});
      if (!response.ok) throw new Error("Archived game returned HTTP " + response.status);
      const gameHtml = prepareGameHtml(await response.text(), data.game_date);
      $("replay-frame").srcdoc = gameHtml;
      $("replay-state").hidden=true; $("replay-frame").hidden=false;
    } catch(e) { $("replay-state").textContent="Couldn't open that archived game: "+e.message; }
  }
  async function admin() {
    if (!client) return showConfigError("login-panel");
    const {data:{session}}=await client.auth.getSession();
    const setLoggedIn = async yes => { $("login-panel").hidden=yes; $("upload-panel").hidden=!yes; if(yes) await loadAdminGames(); };
    await setLoggedIn(!!session);
    $("login-form").addEventListener("submit", async e=>{
      e.preventDefault(); const {error}=await client.auth.signInWithPassword({email:$("email").value,password:$("password").value});
      if(error) { $("login-panel").querySelector(".small").textContent=error.message; return; }
      await setLoggedIn(true);
    });
    $("logout").addEventListener("click",async()=>{await client.auth.signOut(); await setLoggedIn(false);});
    $("upload-form").addEventListener("submit",async e=>{
      e.preventDefault(); const status=$("admin-status"); const file=$("game-file").files[0];
      const title=$("title").value.trim(), date=$("game-date-input").value;
      if(!file || !date || !title) return;
      if(file.size > 2*1024*1024) {status.textContent="Please keep HTML files under 2 MB.";return;}
      status.textContent="Uploading…";
      try {
        const path=`${date}/${crypto.randomUUID()}.html`;
        const {error:uploadError}=await client.storage.from("daily-games").upload(path,file,{contentType:"text/html",upsert:false});
        if(uploadError) throw uploadError;
        const {error:dbError}=await client.from("games").upsert({title,game_date:date,storage_path:path,published:true},{onConflict:"game_date"});
        if(dbError) throw dbError;
        status.textContent="Published successfully. The public homepage and archive will now show this game.";
        $("upload-form").reset(); await loadAdminGames();
      } catch(err) {status.textContent="Upload failed: "+err.message;}
    });
  }
  async function loadAdminGames() {
    try { const games=await getGames(); $("admin-games").innerHTML="";
      for(const g of games){const item=document.createElement("div");item.className="archive-item";
        const left=document.createElement("span"),right=document.createElement("span"),strong=document.createElement("strong"),small=document.createElement("small");
        strong.textContent=g.title;small.textContent=dateLabel(g.game_date);left.append(strong,small);right.textContent="PUBLISHED";item.append(left,right);$("admin-games").append(item);}
    } catch(e) {$("admin-status").textContent="Couldn't load published games: "+e.message;}
  }
  if ($("state")) home();
  if ($("archive-state")) archive();
  if ($("replay-state")) replay();
  if ($("login-panel")) admin();
})();